create unique index PRIMARY_KEY_A
    on SIMPTOM (ID);

