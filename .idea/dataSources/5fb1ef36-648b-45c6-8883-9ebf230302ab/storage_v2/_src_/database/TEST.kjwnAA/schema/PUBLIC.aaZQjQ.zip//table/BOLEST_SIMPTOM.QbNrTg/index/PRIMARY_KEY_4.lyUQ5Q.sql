create unique index PRIMARY_KEY_4
    on BOLEST_SIMPTOM (BOLEST_ID, SIMPTOM_ID);

