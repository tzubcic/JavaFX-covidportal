create unique index PRIMARY_KEY_A1
    on ZUPANIJA (ID);

